# Fazenda Cria App
Sistema de gestão para fazenda de cria bovina.